﻿#define F_CPU 16000000L
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>
#include	"lcd.h"
#define	MAX_LCD_STRING	0x40
volatile int  ADC_result, adc_rq=0, adc_result=0;
ISR(ADC_vect)
{
	if(ADC & 1<<9)
	{
		for(int i=0; i<10; i++)
			ADC_result = ADC ^= 1<<i;
	}else
		ADC_result = ADC;
	
	//ADC_result = (ADC & 1<<9) ? 0b1111110000000000 | ADC : ADC;
	//ADC_result = (ADC & 1<<9) ? (ADC &= ~ADCH+1) : ADC;
}
void ADC_init(void)
{
	ADMUX |= 1<<REFS0;
	ADMUX |= 0b00001001;
	//1<<MUX3 | 1<<MUX0; //01001 (ADC1 - ADC0) * 10 Mode;
	// -1 - 0 * 100 = -100 ?
	ADCSRA = 1<<ADEN | 1<<ADSC | 1<<ADFR | 1<<ADIE | 7;
	// ADC 활성화, 프리스케일러 CPU 분주비=128
	sei();
}
int	main(void)
{
	char lcd_string[2][MAX_LCD_STRING];
	LCD_init();
	ADC_init();
	sprintf(lcd_string[0], "ADC 01001 (x10)");
	sprintf(lcd_string[1], "temp: ");
	LCD_str_write(0, 0, lcd_string[0]);
	LCD_str_write(1, 0, lcd_string[1]);
	while (1)
	{
		_delay_us(1);
		sprintf(lcd_string[1], "%-5.d[`C]", ADC_result);
		LCD_str_write(1, 6, lcd_string[1]);
	}
	return 0;
}